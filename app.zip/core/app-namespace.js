(function (global) {
    const App = global.App = global.App || {};

    App.state   = App.state   || {};
    App.ui      = App.ui      || {};
    App.domain  = App.domain  || {};
    App.config  = App.config  || {};
    App.modules = App.modules || {};
})(window);